﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Wz : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            if (Request.QueryString["id"] == null)
                Response.Write("<script>alert('请选择新闻标题!'),location='Default.aspx'</script>");
            else
            {
               
            }
    }
}