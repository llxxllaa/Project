﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_Wznr : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
            

    

    protected void Button1_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("Pl.aspx");
    
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("Wz.aspx");
    }

}
