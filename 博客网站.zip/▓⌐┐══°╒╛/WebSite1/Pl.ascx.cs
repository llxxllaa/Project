﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class Modules_Pl : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = DateTime.Now.ToString();
   
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if(TextBox1 .Text ==""||TextBox4 .Text =="")
        {
            Response.Write("不能留空！");
            return;
        }
        string connstr = ConfigurationManager.ConnectionStrings["swConnectionString"].ToString();
        string sqlstr = "insert into sw_comment(Name,cotime,aid,say) values (@p1,@p2,@p3,@p4)";
        SqlConnection myconn = new SqlConnection(connstr);
        SqlCommand mycmd = new SqlCommand(sqlstr, myconn);
        mycmd.Parameters.Add("p1", SqlDbType.NVarChar).Value = TextBox1.Text;
        mycmd.Parameters.Add("p2", SqlDbType.NVarChar).Value = Label1.Text;
        mycmd.Parameters.Add("p3", SqlDbType.NVarChar).Value = TextBox3.Text;
        mycmd.Parameters.Add("p4", SqlDbType.NVarChar).Value = TextBox4.Text;
        myconn.Open();
        mycmd.ExecuteNonQuery();  
        Response.Write("<script>alert('发表评论成功成功!'),location='Default.aspx'</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("Default.aspx");
    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
}