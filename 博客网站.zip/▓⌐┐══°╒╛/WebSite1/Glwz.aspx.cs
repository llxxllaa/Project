﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class Glwz : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["name"] == null)
            Response.Write("<script>alert('请登录！'),'Dl.aspx'</script>");
        string a = "data source=LENOVO-PC; initial catalog=sw;integrated security=true";
        string b = "select *from sw_content01 where Name='" + Session["name"] + "' "; 
    }

}