﻿
using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Data.SqlClient;

public partial class Addwz : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string a = "data source=LENOVO-PC; initial catalog=sw;integrated security=true";
        string b = "select count(*)from sw_content01 where Name='" + Session["name"] + "' ";       
            
        SqlConnection con = new SqlConnection(a);
        SqlCommand cmd = new SqlCommand(b, con);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
        {
           
            int count = Convert.ToInt32(dr[0].ToString().Trim()) + 1;
            Label1.Text = count.ToString();
        }
    }
   


            protected void Button1_Click1(object sender, EventArgs e)
            {
                string sqlstr = "insert into sw_content01(id,title,cid,content,Name,Date) values(@p,@p0,@p1,@p2,@n,@p3)";//定义sqlsrt
                SqlParameter[] paras = { 
                                            new SqlParameter("p", Label1 .Text),
                                     new SqlParameter("p0", TextBox2.Text),
                                   new SqlParameter("p1", DropDownList1.SelectedValue),
                                    new SqlParameter("p2", TextBox1.Text),   
                              new SqlParameter("n", Session["name"]), 
                              new SqlParameter("p3", DateTime .Now),
                         
                               };//定义paras
                int result = ConnDBHelper.ExecuteCommand(sqlstr, paras);//调用ConnDBHelper.ExecuteCommand(sqlstr, paras);
                if (result == 1)
                {
                    Response.Write("<script>alert('信息添加成功！')</script>");
                    TextBox1 .Text="";
                    TextBox2.Text = "";
                }
                else
                    Response.Write("<script>alert('信息添加失败！')</script>");
              
            }
}