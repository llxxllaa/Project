﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Modules_DL : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
     string a = "data source=LENOVO-PC; initial catalog=sw;integrated security=true";
    String b = "select * from sw_config";
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text.Trim() == "" || TextBox2.Text.Trim() == "")
            Response.Write("<script>alert('信息不完整，填写完整！'),location='Dl.aspx'</script>");

        SqlConnection con = new SqlConnection(a);
        SqlCommand cmd = new SqlCommand(b, con);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();

        while (dr.Read())
        {
                if (TextBox1.Text == dr[1].ToString().Trim() && TextBox2.Text == dr[2].ToString().Trim())
                {
                    Session["name"] = TextBox1.Text;
                   Response.Write("<script>alert('登录成功!'),location='Ht.aspx'</script>");
                }
                else
                {
                    Response.Write("<script>alert('密码错误!'),location='Dl.aspx'</script>");
                }
         
        }
  

    }
    
    protected void  Button2_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect("Default.aspx");

}
    protected void Button3_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("Zc.aspx");
    }
}
