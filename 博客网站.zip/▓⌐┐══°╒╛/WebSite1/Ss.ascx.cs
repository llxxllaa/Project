﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_WebUserControl5 : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

            BindRepeater();
        
    }
    private void BindRepeater()
    {
        string a = "data source=LENOVO-PC; initial catalog=sw;integrated security=true";
        String b = "select id,title,cid,Name,Date from sw_content01 where cid='" + DropDownList1.Text + "'";
        SqlConnection con = new SqlConnection(a);
        SqlCommand cmd = new SqlCommand(b, con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        Repeater.DataSource = dt;
        Repeater.DataBind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("Default.aspx");
  
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindRepeater();
    }
}