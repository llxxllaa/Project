﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Modules_DL : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
     
        string sqlstr = "insert into sw_config(name,pass,title,keywords,description,jianjie) values (@p1,@p2,@p3,@p4,@5,@6)";
        SqlParameter[] paras = { new SqlParameter("p1", TextBox1.Text),
                                 new SqlParameter("p2", TextBox2.Text),
                                  new SqlParameter("p3", TextBox3.Text),
                                   new SqlParameter("p4", TextBox4.Text),
                                    new SqlParameter("p5", TextBox5.Text),
                                  new SqlParameter("p6", TextBox6.Text),
                         
                               };
        int result = ConnDBHelper.ExecuteCommand(sqlstr, paras);
        if (result == 1)
            Response.Write("<script>alert('注册成功！')</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("Default.aspx");
    }
}